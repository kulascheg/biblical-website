const verses = [
  {text: "And I looked, and behold, a pale horse! And its rider’s name was Death, and Hades followed him. – Revelation 6:8"},
  {text: "Then I lifted up my eyes and saw, and behold, four horns! – Zechariah 1:18"},
  {text: "Behold, I am sending for many fishers, declares the LORD, and they shall catch them; and afterward I will send for many hunters. – Jeremiah 16:16"},
  {text: "Out of the north calamity shall break forth on all the inhabitants of the land. – Jeremiah 1:14"},
  {text: "And he measured the wall thereof, an hundred and forty and four cubits. – Revelation 21:17"},
  {text: "I saw in the night visions, and behold, with the clouds of heaven there came one like a son of man. – Daniel 7:13"},
  {text: "Make yourself bald and cut off your hair, for the children of your delight; enlarge your baldness like the eagle. – Micah 1:16"},
  {text: "Behold, I will make you a threshing sledge, new, sharp, and having teeth. – Isaiah 41:15"}
];

function getRandomVerse() {
  const verse = verses[Math.floor(Math.random() * verses.length)];
  document.getElementById('verse-box').innerText = verse.text;
}
document.addEventListener('DOMContentLoaded', getRandomVerse);
